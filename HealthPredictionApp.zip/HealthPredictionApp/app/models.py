"""
Database layer for Users and Patients.
"""

import sqlite3
import os

# Database Path standard
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DB_PATH = os.path.join(BASE_DIR, "instance", "patients.db")


def get_db_connection():
    """Create a SQLite database connection with Row factory."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the users and patients tables if they do not exist."""
    conn = get_db_connection()
    
    # Create users table
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            fullname      TEXT    NOT NULL,
            email         TEXT    UNIQUE NOT NULL,
            password_hash TEXT    NOT NULL,
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    
    # Create patients table
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS patients (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name      TEXT    NOT NULL,
            dob            TEXT    NOT NULL,
            email          TEXT    NOT NULL,
            glucose        REAL    NOT NULL,
            haemoglobin    REAL    NOT NULL,
            cholesterol    REAL    NOT NULL,
            remarks        TEXT    DEFAULT '',
            risk_level     TEXT    DEFAULT 'Healthy',
            recommendation TEXT    DEFAULT '',
            created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()
    conn.close()


# ──────────────────────────────────────────────
# User CRUD Helpers
# ──────────────────────────────────────────────

def create_user(fullname: str, email: str, password_hash: str) -> int:
    """Insert a new user record and return its id."""
    conn = get_db_connection()
    cursor = conn.execute(
        "INSERT INTO users (fullname, email, password_hash) VALUES (?, ?, ?)",
        (fullname, email, password_hash),
    )
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()
    return user_id


def get_user_by_email(email: str) -> dict | None:
    """Fetch a user by email."""
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_user_by_id(user_id: int) -> dict | None:
    """Fetch a user by id."""
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_user_profile(user_id: int, fullname: str, email: str) -> bool:
    """Update user's name and email."""
    conn = get_db_connection()
    conn.execute(
        "UPDATE users SET fullname = ?, email = ? WHERE id = ?",
        (fullname, email, user_id),
    )
    conn.commit()
    changed = conn.total_changes
    conn.close()
    return changed > 0


def update_user_password(user_id: int, password_hash: str) -> bool:
    """Update user's password hash."""
    conn = get_db_connection()
    conn.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (password_hash, user_id),
    )
    conn.commit()
    changed = conn.total_changes
    conn.close()
    return changed > 0


# ──────────────────────────────────────────────
# Patient CRUD Helpers
# ──────────────────────────────────────────────

def create_patient(data: dict) -> int:
    """Insert a new patient record and return its id."""
    conn = get_db_connection()
    cursor = conn.execute(
        """
        INSERT INTO patients (full_name, dob, email, glucose, haemoglobin, cholesterol, remarks, risk_level, recommendation)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data["full_name"],
            data["dob"],
            data["email"],
            data["glucose"],
            data["haemoglobin"],
            data["cholesterol"],
            data.get("remarks", ""),
            data.get("risk_level", "Healthy"),
            data.get("recommendation", ""),
        ),
    )
    conn.commit()
    patient_id = cursor.lastrowid
    conn.close()
    return patient_id


def get_all_patients() -> list:
    """Return all patient records."""
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_patient(patient_id: int) -> dict | None:
    """Fetch a single patient by ID."""
    conn = get_connection() if "get_connection" in globals() else get_db_connection()
    row = conn.execute("SELECT * FROM patients WHERE id = ?", (patient_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_patient(patient_id: int, data: dict) -> bool:
    """Update a patient record."""
    conn = get_db_connection()
    conn.execute(
        """
        UPDATE patients
        SET full_name      = ?,
            dob            = ?,
            email          = ?,
            glucose        = ?,
            haemoglobin    = ?,
            cholesterol    = ?,
            remarks        = ?,
            risk_level     = ?,
            recommendation = ?,
            updated_at     = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            data["full_name"],
            data["dob"],
            data["email"],
            data["glucose"],
            data["haemoglobin"],
            data["cholesterol"],
            data.get("remarks", ""),
            data.get("risk_level", "Healthy"),
            data.get("recommendation", ""),
            patient_id,
        ),
    )
    conn.commit()
    changed = conn.total_changes
    conn.close()
    return changed > 0


def delete_patient(patient_id: int) -> bool:
    """Delete a patient record."""
    conn = get_db_connection()
    conn.execute("DELETE FROM patients WHERE id = ?", (patient_id,))
    conn.commit()
    changed = conn.total_changes
    conn.close()
    return changed > 0
