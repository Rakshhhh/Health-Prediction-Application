# 🏥 Health Prediction Application

A full-stack health prediction web application built with **Python Flask**, **SQLite**, **Bootstrap 5**, and **Scikit-learn**. It allows healthcare providers to manage patient records and predict health risk levels based on blood biomarkers.

---

## ✨ Features

- **CRUD Operations** — Create, Read, Update, and Delete patient records
- **Health Risk Prediction** — Scikit-learn model predicts risk level (Low / Moderate / High) based on Glucose, Haemoglobin, and Cholesterol values
- **Input Validation** — Email format validation, future DOB prevention, numeric blood value checks
- **Responsive UI** — Bootstrap 5 with a modern, dark-themed glassmorphism design
- **SQLite Database** — Lightweight, zero-configuration database

---

## 📁 Project Structure

```
HealthPredictionApp/
├── app.py                  # Flask application entry point
├── config.py               # Configuration settings
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── models/
│   ├── database.py         # SQLite database models & helpers
│   └── predictor.py        # Scikit-learn health risk predictor
├── static/
│   └── css/
│       └── style.css       # Custom styles
└── templates/
    ├── base.html           # Base layout template
    ├── index.html          # Patient list (home)
    ├── add_patient.html    # Add new patient form
    ├── edit_patient.html   # Edit patient form
    └── view_patient.html   # View patient details
```

---

## 🚀 Getting Started

### Prerequisites

- Python 3.9 or higher
- pip

### Installation

1. **Clone or navigate to the project directory**
   ```bash
   cd HealthPredictionApp
   ```

2. **Create a virtual environment** (recommended)
   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   python app.py
   ```

5. **Open your browser** and navigate to:
   ```
   http://127.0.0.1:5000
   ```

---

## 🧠 Health Risk Prediction Model

The application uses a **Random Forest Classifier** trained on synthetic medical data to predict health risk based on three biomarkers:

| Feature       | Description                        |
|---------------|------------------------------------|
| Glucose       | Blood glucose level (mg/dL)        |
| Haemoglobin   | Haemoglobin concentration (g/dL)   |
| Cholesterol   | Total cholesterol level (mg/dL)    |

### Risk Levels

| Risk Level  | Criteria (general)                                           |
|-------------|--------------------------------------------------------------|
| 🟢 Low      | Normal glucose, haemoglobin, and cholesterol                 |
| 🟡 Moderate | Borderline values in one or more biomarkers                  |
| 🔴 High     | Significantly abnormal values across multiple biomarkers     |

---

## 🛠️ Tech Stack

| Layer     | Technology          |
|-----------|---------------------|
| Backend   | Python Flask        |
| Database  | SQLite              |
| Frontend  | HTML, CSS, Bootstrap 5 |
| ML Model  | Scikit-learn (Random Forest) |

---

## 📄 License

This project is for educational and demonstration purposes.
