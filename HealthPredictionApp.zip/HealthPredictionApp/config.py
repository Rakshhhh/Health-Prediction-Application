import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "health-prediction-app-secret-key-2026")
    DATABASE = os.path.join(BASE_DIR, "instance", "patients.db")
    DEBUG = True
