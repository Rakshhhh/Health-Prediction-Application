def get_recommendations(risk_level: str) -> list[str]:
    """Return a list of health recommendations based on the risk level.
    This is a simple placeholder implementation; in a real app you might pull
    from a knowledge base or AI service.
    """
    common = [
        "Maintain a balanced diet",
        "Exercise regularly (150 mins/week)",
        "Stay hydrated",
        "Get regular health check‑ups",
    ]
    if risk_level == "Healthy":
        return ["Continue your healthy lifestyle."] + common
    if risk_level == "Prediabetes Risk":
        return [
            "Monitor blood sugar levels",
            "Reduce sugary foods",
            "Increase fiber intake",
        ] + common
    if risk_level == "Diabetes Risk":
        return [
            "Consult a healthcare professional",
            "Consider medication as prescribed",
            "Follow a low‑carb diet",
        ] + common
    if risk_level == "High Cholesterol Risk":
        return [
            "Limit saturated fats",
            "Increase omega‑3 intake",
            "Regular lipid profile checks",
        ] + common
    if risk_level == "Heart Disease Risk":
        return [
            "Quit smoking",
            "Control blood pressure",
            "Limit salt intake",
        ] + common
    return common
