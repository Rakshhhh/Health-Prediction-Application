from flask import Flask
from .auth import auth_bp
from .dashboard import dashboard_bp
# from .patients import patients_bp
# from .analytics import analytics_bp
# from .profile import profile_bp

def register_blueprints(app: Flask):
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    # app.register_blueprint(patients_bp)
    # app.register_blueprint(analytics_bp)
    # app.register_blueprint(profile_bp)
