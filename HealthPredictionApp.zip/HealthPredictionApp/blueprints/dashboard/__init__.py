from flask import Blueprint, render_template, session, redirect, url_for
from models.database import get_all_patients
# from flask_login import login_required  # removed

dashboard_bp = Blueprint('dashboard_bp', __name__, template_folder='../../templates')

@dashboard_bp.route('/dashboard')
def dashboard():
    """Dashboard view – provides stats and chart data."""
    if "user_id" not in session:
        return redirect(url_for('auth.login'))
    patients = get_all_patients()
    return render_template('dashboard.html', fullname=session.get('fullname'), patients=patients)
