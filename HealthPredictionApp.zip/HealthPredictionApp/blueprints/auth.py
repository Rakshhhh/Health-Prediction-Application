from flask import Blueprint, render_template, request, flash, redirect, url_for, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, login_required, current_user
from models.database import create_user, get_user_by_email

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/')
def home():
    return redirect(url_for('dashboard_bp.dashboard'))

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        fullname = request.form.get('fullname', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')
        errors = []
        if not fullname:
            errors.append('Full Name is required.')
        if not email:
            errors.append('Email is required.')
        if not password:
            errors.append('Password is required.')
        elif len(password) < 8:
            errors.append('Password must be at least 8 characters.')
        if password != confirm:
            errors.append('Passwords do not match.')
        if not errors:
            if get_user_by_email(email):
                errors.append('Email already registered.')
            else:
                pwd_hash = generate_password_hash(password)
                create_user(fullname, email, pwd_hash)
                flash('Registration successful, please log in.', 'success')
                return redirect(url_for('auth.login'))
        for e in errors:
            flash(e, 'danger')
    return render_template('register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        user = get_user_by_email(email)
        if user and check_password_hash(user['password_hash'], password):
            # Create a simple User object for Flask-Login
            from models.user import User  # import the User class defined in models/user.py
            login_user(User(user['id'], user['fullname'], user['email'], user['password_hash']))
            flash(f"Welcome back, {user['fullname']}!", 'success')
            return redirect(url_for('dashboard_bp.dashboard'))
        else:
            flash('Invalid credentials.', 'danger')
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('auth.login'))
