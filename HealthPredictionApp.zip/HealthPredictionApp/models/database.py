"""
SQLite database helper — manages patient records and users.
"""

import sqlite3
import os


def get_db_path():
    """Return the absolute path to the SQLite database file."""
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    db_dir = os.path.join(base_dir, "instance")
    os.makedirs(db_dir, exist_ok=True)
    return os.path.join(db_dir, "patients.db")


def get_connection():
    """Open a connection with row-factory enabled."""
    conn = sqlite3.connect(get_db_path())
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the tables if they don't already exist."""
    conn = get_connection()
    # Create patients table
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS patients (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name   TEXT    NOT NULL,
            dob         TEXT    NOT NULL,
            email       TEXT    NOT NULL,
            glucose     REAL    NOT NULL,
            haemoglobin REAL    NOT NULL,
            cholesterol REAL    NOT NULL,
            risk_level  TEXT    DEFAULT 'Healthy',
            recommendation TEXT DEFAULT '',
            risk_score  REAL    DEFAULT 0,
            remarks     TEXT    DEFAULT '',
            created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    # Create users table
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            fullname      TEXT    NOT NULL,
            email         TEXT    UNIQUE NOT NULL,
            password_hash TEXT    NOT NULL,
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()
    conn.close()


# --------------- User Auth Helpers ---------------

def create_user(fullname: str, email: str, password_hash: str) -> int:
    """Insert a new user record and return its id."""
    conn = get_connection()
    cursor = conn.execute(
        "INSERT INTO users (fullname, email, password_hash) VALUES (?, ?, ?)",
        (fullname, email, password_hash),
    )
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()
    return user_id


def get_user_by_email(email: str) -> dict | None:
    """Fetch a single user by email."""
    conn = get_connection()
    row = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    conn.close()
    return dict(row) if row else None


# --------------- Patient CRUD helpers ---------------

def create_patient(data: dict) -> int:
    """Insert a new patient record and return its id."""
    conn = get_connection()
    cursor = conn.execute(
        """
        INSERT INTO patients (full_name, dob, email, glucose, haemoglobin, cholesterol, risk_level, recommendation, risk_score, remarks)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data["full_name"],
            data["dob"],
            data["email"],
            data["glucose"],
            data["haemoglobin"],
            data["cholesterol"],
            data.get("risk_level", "Healthy"),
            data.get("recommendation", ""),
            data.get("remarks", ""),
        ),
    )
    conn.commit()
    patient_id = cursor.lastrowid
    conn.close()
    return patient_id


def get_all_patients() -> list:
    """Return every patient row as a list of dicts."""
    conn = get_connection()
    rows = conn.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_patient(patient_id: int) -> dict | None:
    """Fetch a single patient by id."""
    conn = get_connection()
    row = conn.execute("SELECT * FROM patients WHERE id = ?", (patient_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_patient(patient_id: int, data: dict) -> bool:
    """Update an existing patient record."""
    conn = get_connection()
    conn.execute(
        """
        UPDATE patients
        SET full_name   = ?,
            dob         = ?,
            email       = ?,
            glucose     = ?,
            haemoglobin = ?,
            cholesterol = ?,
            risk_level  = ?,
            recommendation = ?,
            remarks     = ?,
            updated_at  = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            data["full_name"],
            data["dob"],
            data["email"],
            data["glucose"],
            data["haemoglobin"],
            data["cholesterol"],
            data.get("risk_level", "Healthy"),
            data.get("recommendation", ""),
            data.get("remarks", ""),
            patient_id,
        ),
    )
    conn.commit()
    changed = conn.total_changes
    conn.close()
    return changed > 0


def delete_patient(patient_id: int) -> bool:
    """Delete a patient record by id."""
    conn = get_connection()
    conn.execute("DELETE FROM patients WHERE id = ?", (patient_id,))
    conn.commit()
    changed = conn.total_changes
    conn.close()
    return changed > 0
