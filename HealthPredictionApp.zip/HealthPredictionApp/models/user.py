from flask_login import UserMixin

class User(UserMixin):
    def __init__(self, id, fullname, email, password_hash):
        self.id = id
        self.fullname = fullname
        self.email = email
        self.password_hash = password_hash
