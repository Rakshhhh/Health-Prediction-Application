"""
Health-risk predictor using a scikit-learn Random Forest classifier.

The model is trained on synthetic data that maps (glucose, haemoglobin,
cholesterol) → risk level (Low / Moderate / High).  Training happens once
at application startup and the model is cached in memory.
"""

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# ---- module-level singleton ----
_model: RandomForestClassifier | None = None


def _generate_synthetic_data(n_samples: int = 1500, seed: int = 42):
    """
    Generate labelled synthetic patient data.

    Rough clinical heuristics used for labelling:
      - Low risk   : glucose < 140, haemoglobin 12-17.5, cholesterol < 200
      - High risk  : glucose > 200 OR haemoglobin < 10 OR cholesterol > 280
      - Moderate   : everything else
    """
    rng = np.random.RandomState(seed)

    glucose     = rng.uniform(60, 350, n_samples)    # mg/dL
    haemoglobin = rng.uniform(5, 20, n_samples)      # g/dL
    cholesterol = rng.uniform(100, 400, n_samples)   # mg/dL

    labels = []
    for g, h, c in zip(glucose, haemoglobin, cholesterol):
        high_signals = 0
        if g > 200:
            high_signals += 1
        if h < 10:
            high_signals += 1
        if c > 280:
            high_signals += 1

        low_signals = 0
        if g < 140:
            low_signals += 1
        if 12 <= h <= 17.5:
            low_signals += 1
        if c < 200:
            low_signals += 1

        if high_signals >= 2:
            labels.append("High Risk")
        elif high_signals == 1 and low_signals <= 1:
            labels.append("High Risk")
        elif low_signals == 3:
            labels.append("Low Risk")
        elif low_signals >= 2 and high_signals == 0:
            labels.append("Low Risk")
        else:
            labels.append("Moderate Risk")

    X = np.column_stack([glucose, haemoglobin, cholesterol])
    y = np.array(labels)
    return X, y


def train_model() -> dict:
    """
    Train the Random Forest model and store it in the module-level cache.
    Returns a dict with training metrics.
    """
    global _model

    X, y = _generate_synthetic_data()
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    _model = RandomForestClassifier(
        n_estimators=120,
        max_depth=10,
        random_state=42,
        n_jobs=-1,
    )
    _model.fit(X_train, y_train)

    y_pred = _model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    return {"accuracy": round(acc * 100, 2), "train_size": len(X_train), "test_size": len(X_test)}


def predict_risk(glucose: float, haemoglobin: float, cholesterol: float) -> tuple:
    """
    Predict health risk for a single patient and return a tuple of
    (risk_label, confidence_score).

    The RandomForest model provides class probabilities via ``predict_proba``.
    We take the highest probability as the confidence (0‑100%).
    """
    if _model is None:
        train_model()
    features = np.array([[glucose, haemoglobin, cholesterol]])
    # get class probabilities
    probs = _model.predict_proba(features)[0]
    # map index to label using the model's classes_
    idx = np.argmax(probs)
    prediction = _model.classes_[idx]
    confidence = float(probs[idx]) * 100.0
    return prediction, confidence
