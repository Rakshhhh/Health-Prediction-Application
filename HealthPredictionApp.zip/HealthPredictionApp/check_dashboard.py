import urllib.request, ssl, sys
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
try:
    resp = urllib.request.urlopen('http://127.0.0.1:5000/dashboard', context=ctx)
    print('Status', resp.getcode())
except Exception as e:
    print('Error', e)
