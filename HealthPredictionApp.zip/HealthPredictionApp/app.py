"""
Integrated Health Prediction Application — Flask entry point.
Contains User Authentication and Patient Health Risk Prediction.
"""

import re
from datetime import date, datetime
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash

from config import Config
from models.database import (
    init_db,
    create_patient,
    get_all_patients,
    get_patient,
    update_patient,
    delete_patient,
    create_user,
    get_user_by_email,
)
from models.predictor import train_model, predict_risk
from utils.recommendations import get_recommendations

app = Flask(__name__)
app.config.from_object(Config)

# Enforce secure session key
app.secret_key = app.config["SECRET_KEY"]

from blueprints import register_blueprints
register_blueprints(app)

# Initialize Flask-Login
from flask_login import LoginManager, login_user, logout_user, login_required, current_user

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

from models.user import User

@login_manager.user_loader
def load_user(user_id):
    user = get_user_by_email(session.get('email'))
    if user:
        return User(user['id'], user['fullname'], user['email'], user['password_hash'])
    return None

EMAIL_RE = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")


# ──────────────────────────────────────────────
# Decorators / Middleware
# ──────────────────────────────────────────────
def login_required(f):
    """Decorator to protect routes from unauthorized access."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


# ──────────────────────────────────────────────
# Form Validation Helpers
# ──────────────────────────────────────────────
def validate_patient_form(form) -> list[str]:
    """Return a list of validation error messages for patient fields (empty == valid)."""
    errors = []

    # Full name
    if not form.get("full_name", "").strip():
        errors.append("Full Name is required.")

    # Email
    email = form.get("email", "").strip()
    if not email:
        errors.append("Email is required.")
    elif not EMAIL_RE.match(email):
        errors.append("Please enter a valid email address.")

    # Date of birth
    dob_str = form.get("dob", "").strip()
    if not dob_str:
        errors.append("Date of Birth is required.")
    else:
        try:
            dob = datetime.strptime(dob_str, "%Y-%m-%d").date()
            if dob > date.today():
                errors.append("Date of Birth cannot be a future date.")
        except ValueError:
            errors.append("Date of Birth must be in YYYY-MM-DD format.")

    # Blood values
    for field, label in [("glucose", "Glucose"), ("haemoglobin", "Haemoglobin"), ("cholesterol", "Cholesterol")]:
        val = form.get(field, "").strip()
        if not val:
            errors.append(f"{label} is required.")
        else:
            try:
                num = float(val)
                if num < 0:
                    errors.append(f"{label} must be a positive number.")
            except ValueError:
                errors.append(f"{label} must be a valid number.")

    return errors


# ──────────────────────────────────────────────
# Routes: Auth
# ──────────────────────────────────────────────

@app.route("/")
def home():
    """Redirect root access to dashboard."""
    return redirect(url_for("dashboard_bp.dashboard"))


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register page."""
    if "user_id" in session:
        return redirect(url_for("dashboard_bp.dashboard"))

    if request.method == "POST":
        fullname = request.form.get("fullname", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        errors = []

        if not fullname:
            errors.append("Full Name is required.")

        if not email:
            errors.append("Email Address is required.")
        elif not EMAIL_RE.match(email):
            errors.append("Please enter a valid email address.")

        if not password:
            errors.append("Password is required.")
        elif len(password) < 8:
            errors.append("Password must be at least 8 characters long.")

        if password != confirm_password:
            errors.append("Password and Confirm Password must match.")

        if not errors:
            existing_user = get_user_by_email(email)
            if existing_user:
                errors.append("An account with this email address already exists.")
            else:
                try:
                    password_hash = generate_password_hash(password)
                    create_user(fullname, email, password_hash)
                    flash("Registration successful! Please login below.", "success")
                    return redirect(url_for("login"))
                except Exception as e:
                    errors.append("An error occurred during registration. Please try again.")

        for err in errors:
            flash(err, "danger")
        return render_template("register.html", form_data=request.form)

    return render_template("register.html", form_data=None)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page."""
    if "user_id" in session:
        return redirect(url_for("dashboard_bp.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        if not email or not password:
            flash("Please enter both email and password.", "danger")
            return render_template("login.html", email=email)

        user = get_user_by_email(email)

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["fullname"] = user["fullname"]
            session["email"] = user["email"]
            flash(f"Welcome back, {user['fullname']}!", "success")
            # Log the user in via Flask-Login
            login_user(User(user['id'], user['fullname'], user['email'], user['password_hash']))
            return redirect(url_for('dashboard_bp.dashboard'))
        else:
            flash("Invalid email or password. Please try again.", "danger")
            return render_template("login.html", email=email)

    return render_template("login.html", email=None)


@app.route("/logout")
def logout():
    """Clear session and redirect to login."""
    session.clear()
    flash("You have successfully logged out.", "success")
    return redirect(url_for("login"))


# ──────────────────────────────────────────────
# Routes: Core Protected Pages
# ──────────────────────────────────────────────

# Dashboard route moved to blueprint (see blueprints/dashboard)


@app.route("/patients")
@login_required
def view_all_patients():
    """View all patient records in a list/table."""
    patients = get_all_patients()
    return render_template("patients.html", patients=patients)


@app.route("/add-patient", methods=["GET", "POST"])
@login_required
def add_patient():
    """Add Patient Form."""
    if request.method == "POST":
        errors = validate_patient_form(request.form)
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("add_patient.html", form=request.form)

        glucose = float(request.form["glucose"])
        haemoglobin = float(request.form["haemoglobin"])
        cholesterol = float(request.form["cholesterol"])

        # Predict risk using ML model
        risk = predict_risk(glucose, haemoglobin, cholesterol)

        # Map model risk to UI risk levels
        if risk == "Low Risk":
            risk_level = "Healthy"
        elif risk == "Moderate Risk":
            risk_level = "Prediabetes Risk"
        else:
            risk_level = "Diabetes Risk"

        # Get recommendations based on risk level
        from utils.recommendations import get_recommendations
        recommendations = get_recommendations(risk_level)
        recommendations_text = "|".join(recommendations)  # store as pipe‑separated string

        data = {
            "full_name": request.form["full_name"].strip(),
            "dob": request.form["dob"].strip(),
            "email": request.form["email"].strip(),
            "glucose": glucose,
            "haemoglobin": haemoglobin,
            "cholesterol": cholesterol,
            "risk_level": risk_level,
            "recommendation": recommendations_text,
            "remarks": f"Predicted Health Risk: {risk}",
        }
        create_patient(data)
        flash("Patient record created successfully!", "success")
        return redirect(url_for("view_all_patients"))

    return render_template("add_patient.html", form={})


@app.route("/patient/<int:patient_id>")
@login_required
def view_patient(patient_id):
    """View patient details."""
    patient = get_patient(patient_id)
    if not patient:
        flash("Patient not found.", "warning")
        return redirect(url_for("view_all_patients"))
    return render_template("view_patient.html", patient=patient)


@app.route("/edit-patient/<int:patient_id>", methods=["GET", "POST"])
@login_required
def edit_patient(patient_id):
    """Edit patient record."""
    patient = get_patient(patient_id)
    if not patient:
        flash("Patient not found.", "warning")
        return redirect(url_for("view_all_patients"))

    if request.method == "POST":
        errors = validate_patient_form(request.form)
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("edit_patient.html", patient=request.form, patient_id=patient_id)

        glucose = float(request.form["glucose"])
        haemoglobin = float(request.form["haemoglobin"])
        cholesterol = float(request.form["cholesterol"])

        risk = predict_risk(glucose, haemoglobin, cholesterol)

        # Predict risk again for updated values
        risk, confidence = predict_risk(glucose, haemoglobin, cholesterol)
        if risk == "Low Risk":
            risk_level = "Healthy"
        elif risk == "Moderate Risk":
            risk_level = "Prediabetes Risk"
        else:
            risk_level = "Diabetes Risk"
        recommendations = get_recommendations(risk_level)
        recommendations_text = "|".join(recommendations)
        data = {
            "full_name": request.form["full_name"].strip(),
            "dob": request.form["dob"].strip(),
            "email": request.form["email"].strip(),
            "glucose": glucose,
            "haemoglobin": haemoglobin,
            "cholesterol": cholesterol,
            "risk_level": risk_level,
            "recommendation": recommendations_text,
            "risk_score": confidence,
            "remarks": f"Predicted Health Risk: {risk}",
        }
        update_patient(patient_id, data)
        flash("Patient record updated successfully!", "success")
        return redirect(url_for("view_patient", patient_id=patient_id))

    return render_template("edit_patient.html", patient=patient, patient_id=patient_id)


@app.route("/delete-patient/<int:patient_id>", methods=["POST"])
@login_required
def delete_patient_route(patient_id):
    """Delete patient record."""
    delete_patient(patient_id)
    flash("Patient record deleted.", "info")
    return redirect(url_for("view_all_patients"))


# ──────────────────────────────────────────────
# Bootstrap Application
# ──────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    metrics = train_model()
    print(f"[OK] ML model trained - accuracy {metrics['accuracy']}% "
          f"(train={metrics['train_size']}, test={metrics['test_size']})")
    app.run(debug=True)
