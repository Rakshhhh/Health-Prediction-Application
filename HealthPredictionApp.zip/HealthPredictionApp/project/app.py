"""
Secure Registration and Login System — Flask entry point.
"""

import re
import os
import sqlite3
import uuid
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash

# ──────────────────────────────────────────────
# App Factory & Config
# ──────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "secure-auth-app-key-2026-xyz")

# SQLite Database configuration
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")

EMAIL_RE = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")


# ──────────────────────────────────────────────
# Database Helpers
# ──────────────────────────────────────────────
def get_db_connection():
    """Create a SQLite database connection with Row factory."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create the users table if it does not exist."""
    conn = get_db_connection()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            fullname      TEXT    NOT NULL,
            email         TEXT    UNIQUE NOT NULL,
            password_hash TEXT    NOT NULL,
            created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()
    conn.close()


# ──────────────────────────────────────────────
# Routes & Controllers
# ──────────────────────────────────────────────

@app.route("/")
def home():
    """Redirect to login or dashboard based on session state."""
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    """Handle new user registration."""
    # If user is already logged in, redirect them to the dashboard
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        fullname = request.form.get("fullname", "").strip()
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        errors = []

        # Validate fullname
        if not fullname:
            errors.append("Full Name is required.")

        # Validate email
        if not email:
            errors.append("Email Address is required.")
        elif not EMAIL_RE.match(email):
            errors.append("Please enter a valid email address.")

        # Validate password length
        if not password:
            errors.append("Password is required.")
        elif len(password) < 8:
            errors.append("Password must be at least 8 characters long.")

        # Validate password match
        if password != confirm_password:
            errors.append("Password and Confirm Password must match.")

        # If validation passed, check unique email and save
        if not errors:
            conn = get_db_connection()
            user = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
            
            if user:
                errors.append("An account with this email address already exists.")
                conn.close()
            else:
                try:
                    password_hash = generate_password_hash(password)
                    conn.execute(
                        "INSERT INTO users (fullname, email, password_hash) VALUES (?, ?, ?)",
                        (fullname, email, password_hash),
                    )
                    conn.commit()
                    conn.close()

                    flash("Registration successful! Please login below.", "success")
                    return redirect(url_for("login"))
                except Exception as e:
                    conn.close()
                    errors.append("An error occurred. Please try again.")

        # If errors occurred, flash them all and re-render template with existing fields
        for err in errors:
            flash(err, "danger")

        return render_template("register.html", form_data=request.form)

    return render_template("register.html", form_data=None)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Handle user authentication."""
    # If user is already logged in, redirect them to the dashboard
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        if not email or not password:
            flash("Please enter both email and password.", "danger")
            return render_template("login.html", email=email)

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user["password_hash"], password):
            # Session protection setup
            session.clear()
            session["user_id"] = user["id"]
            session["fullname"] = user["fullname"]
            session["email"] = user["email"]
            # Generate a temporary session tracking ID for display
            session["session_id"] = str(uuid.uuid4())[:18]

            flash(f"Welcome back, {user['fullname']}!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid email or password. Please try again.", "danger")
            return render_template("login.html", email=email)

    return render_template("login.html", email=None)


@app.route("/dashboard")
def dashboard():
    """Render protected User Dashboard."""
    # Prevent access to dashboard without login
    if "user_id" not in session:
        flash("Please log in to access the dashboard.", "warning")
        return redirect(url_for("login"))

    return render_template(
        "dashboard.html",
        fullname=session.get("fullname"),
        email=session.get("email"),
        session_id=session.get("session_id"),
    )


@app.route("/logout")
def logout():
    """Log the user out and clear the session."""
    session.clear()
    flash("You have successfully logged out.", "success")
    return redirect(url_for("login"))


# ──────────────────────────────────────────────
# Bootstrap Entrypoint
# ──────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    # Runs on standard port 5001 to prevent conflicts with the health prediction app (which runs on 5000)
    app.run(debug=True, port=5001)
